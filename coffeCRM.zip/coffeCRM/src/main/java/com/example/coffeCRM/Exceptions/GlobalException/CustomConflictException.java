package com.example.coffeCRM.Exceptions.GlobalException;

public class CustomConflictException extends RuntimeException {
    public CustomConflictException(String message) {
        super(message);
    }
}
