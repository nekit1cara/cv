package com.example.coffeCRM.Entity.Coffee;

import com.example.coffeCRM.Entity.Carts.CartItems;
import com.example.coffeCRM.Entity.Orders.OrderItems;
import com.example.coffeCRM.Enums.FillerType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class CoffeeFillers {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private FillerType fillerType;

    private String fillerName;

    private int fillerPrice;

    @JsonIgnore
    @OneToMany(mappedBy = "filler", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<CartItems> cartItems;

    @JsonIgnore
    @OneToMany(mappedBy = "filler", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<OrderItems> orderItems;

}
