package com.example.coffeCRM.Controller.User;

import com.example.coffeCRM.DTO.Coffee.CoffeeDTO;
import com.example.coffeCRM.DTO.Coffee.CoffeeInfoDTO;
import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import com.example.coffeCRM.Enums.CoffeeStatus;
import com.example.coffeCRM.Service.User.interfaces.Coffee.UserCoffeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/coffee")
public class UserCoffeeController {

    private final UserCoffeeService userCoffeeService;

    @Autowired
    public UserCoffeeController(UserCoffeeService userCoffeeService) {
        this.userCoffeeService = userCoffeeService;
    }

    @GetMapping
    public ResponseEntity<Page<CoffeeDTO>> getAllCoffee(@RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "10") int size) {
        return userCoffeeService.getAllCoffee(page, size);
    }

    @GetMapping("/status")
    public ResponseEntity<Page<CoffeeInfoDTO>> getCoffeeByStatus(@RequestParam(defaultValue = "0") int page,
                                                                 @RequestParam(defaultValue = "10") int size,
                                                                 @RequestParam CoffeeStatus status) {
        return userCoffeeService.getCoffeeByStatus(page, size, status);
    }

    @GetMapping("/name")
    public ResponseEntity<CoffeeInfoDTO> getCoffeeByName(@RequestParam String name) {
        return userCoffeeService.getCoffeeByName(name);
    }

}
