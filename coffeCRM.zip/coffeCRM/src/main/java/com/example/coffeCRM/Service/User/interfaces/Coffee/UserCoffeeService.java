package com.example.coffeCRM.Service.User.interfaces.Coffee;

import com.example.coffeCRM.DTO.Coffee.CoffeeDTO;
import com.example.coffeCRM.DTO.Coffee.CoffeeInfoDTO;
import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import com.example.coffeCRM.Enums.CoffeeStatus;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

public interface UserCoffeeService {

    ResponseEntity<Page<CoffeeDTO>> getAllCoffee(int page, int size);

    ResponseEntity<Page<CoffeeInfoDTO>> getCoffeeByStatus(int page, int size, CoffeeStatus status);

    ResponseEntity<CoffeeInfoDTO> getCoffeeByName(String coffeeName);

}
