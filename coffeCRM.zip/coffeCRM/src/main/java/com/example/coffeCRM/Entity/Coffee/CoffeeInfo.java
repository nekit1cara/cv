package com.example.coffeCRM.Entity.Coffee;

import com.example.coffeCRM.Enums.CoffeeStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class CoffeeInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private CoffeeStatus coffeeStatus;

    private String coffeeName;

    private int coffeeWeight;

    private String coffeeDescription;

    private int coffeePrice;

    @JsonIgnore
    @OneToOne(mappedBy = "info", cascade = CascadeType.ALL)
    private Coffee coffee;



}
