package com.example.coffeCRM.DTO.Coffee;

import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import com.example.coffeCRM.Enums.CoffeeStatus;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CoffeeInfoDTO {

    @Enumerated(EnumType.STRING)
    private CoffeeStatus coffeeStatus;

    private String coffeeName;

    private int coffeeWeight;

    private String coffeeDescription;

    private int coffeePrice;


    public static CoffeeInfoDTO fromEntity(CoffeeInfo coffeeInfo) {

        if (coffeeInfo == null) {
            return null;
        }

        return new CoffeeInfoDTO(
                coffeeInfo.getCoffeeStatus(),
                coffeeInfo.getCoffeeName(),
                coffeeInfo.getCoffeeWeight(),
                coffeeInfo.getCoffeeDescription(),
                coffeeInfo.getCoffeePrice()
        );

    }

}
