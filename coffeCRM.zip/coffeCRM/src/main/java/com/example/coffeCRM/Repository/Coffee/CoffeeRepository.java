package com.example.coffeCRM.Repository.Coffee;

import com.example.coffeCRM.Entity.Coffee.Coffee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoffeeRepository extends JpaRepository<Coffee, Long> {
}
