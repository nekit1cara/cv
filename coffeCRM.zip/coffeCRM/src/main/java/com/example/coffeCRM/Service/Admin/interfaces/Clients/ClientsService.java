package com.example.coffeCRM.Service.Admin.interfaces.Clients;

import com.example.coffeCRM.Entity.Clients.Clients;
import com.example.coffeCRM.Enums.ClientStatus;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ClientsService {

    ResponseEntity<Page<Clients>> getAllClients(int page, int size);

    ResponseEntity<Clients> getClientById(Long clientId);

    ResponseEntity<Clients> createClient(Clients client);

    ResponseEntity<List<Clients>> createListClients(List<Clients> clients);

    ResponseEntity<String> updateClientById(Long clientId, Clients client);

    ResponseEntity<String> updateClientStatusById(Long clientId, ClientStatus status);

    ResponseEntity<String> deleteClientById(Long clientId);

}
