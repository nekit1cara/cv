package com.example.coffeCRM.Controller.User;

import com.example.coffeCRM.DTO.Cart.CartItemsDTO;
import com.example.coffeCRM.Entity.Carts.CartItems;
import com.example.coffeCRM.Service.User.interfaces.Carts.UserCartsService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/cart")
public class UserCartsController {

    private final UserCartsService userCartsService;

    @Autowired
    public UserCartsController(UserCartsService userCartsService) {
        this.userCartsService = userCartsService;
    }

    @GetMapping
    public ResponseEntity<Page<CartItemsDTO>> getAllItemsInCart(HttpSession session,
                                                  @RequestParam(defaultValue = "0") int page,
                                                  @RequestParam(defaultValue = "10") int size) {
        return userCartsService.getAllItemsInCart(session, page, size);
    }

    @GetMapping("/item")
    public ResponseEntity<CartItemsDTO> getCartItemById(HttpSession session,
                                                                  @RequestParam Long id) {
        return userCartsService.getItemInCartById(session, id);
    }

    @PostMapping("/add-item")
    public ResponseEntity<String> addItemInCart(HttpSession session,
                                           @RequestBody CartItems item) {
        return userCartsService.addItemToCart(session, item);
    }

    @DeleteMapping("/remove")
    public ResponseEntity<String> removeItemFromCart(HttpSession session,
                                                @RequestParam Long itemId) {
        return userCartsService.removeItemFromCartById(session, itemId);
    }

    @DeleteMapping("/clear")
    public ResponseEntity<String> clearCart(HttpSession session) {
        return userCartsService.clearCart(session);
    }

}
