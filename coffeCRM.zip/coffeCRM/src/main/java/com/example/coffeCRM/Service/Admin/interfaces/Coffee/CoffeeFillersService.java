package com.example.coffeCRM.Service.Admin.interfaces.Coffee;

import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.example.coffeCRM.Enums.FillerType;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface CoffeeFillersService {

    ResponseEntity<Page<CoffeeFillers>> getAllFillers(int page, int size);

    ResponseEntity<Page<CoffeeFillers>> getFillersByType(int page, int size, FillerType type);

    ResponseEntity<CoffeeFillers> getFillerById(Long fillerId);

    ResponseEntity<CoffeeFillers> createFiller(CoffeeFillers filler);

    ResponseEntity<List<CoffeeFillers>> createFillerList(List<CoffeeFillers> fillers);

    ResponseEntity<String> updateFillerById(Long fillerId, CoffeeFillers filler);

    ResponseEntity<String> deleteFillerById(Long fillerId);

}
