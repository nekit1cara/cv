package com.example.coffeCRM.Controller.Admin;

import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import com.example.coffeCRM.Enums.CoffeeStatus;
import com.example.coffeCRM.Service.Admin.interfaces.Coffee.CoffeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/coffee")
public class CoffeeController {

    private final CoffeeService coffeeService;

    @Autowired
    public CoffeeController(CoffeeService coffeeService) {
        this.coffeeService = coffeeService;
    }

    @GetMapping
    public ResponseEntity<Page<Coffee>> getAllCoffee(@RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "10") int size) {
        return coffeeService.getAllCoffee(page, size);
    }

    @GetMapping("/status")
    public ResponseEntity<Page<CoffeeInfo>> getCoffeeByStatus(@RequestParam(defaultValue = "0") int page,
                                                              @RequestParam(defaultValue = "10") int size,
                                                              @RequestParam CoffeeStatus status) {
        return coffeeService.getCoffeeByStatus(page, size, status);
    }

    @GetMapping("/name")
    public ResponseEntity<CoffeeInfo> getCoffeeByName(@RequestParam String name) {
        return coffeeService.getCoffeeByName(name);
    }

    @GetMapping("/id")
    public ResponseEntity<CoffeeInfo> getCoffeeById(@RequestParam Long id) {
        return coffeeService.getCoffeeById(id);
    }

    @PostMapping("/create")
    public ResponseEntity<Coffee> createCoffee(@RequestBody Coffee coffee) {
        return coffeeService.createCoffee(coffee);
    }

    @PostMapping("/create-list")
    public ResponseEntity<List<Coffee>> createCoffeeList(@RequestBody List<Coffee> coffees) {
        return coffeeService.createCoffeeList(coffees);
    }

    @PutMapping("/update/{coffeeId}")
    public ResponseEntity<String> updateCoffeeById(@PathVariable Long coffeeId,@RequestBody Coffee coffee) {
        return coffeeService.updateCoffeeById(coffeeId, coffee);
    }

    @PutMapping("/update/status")
    public ResponseEntity<String> updateCoffeeStatusById(@RequestParam Long id,
                                                    @RequestParam CoffeeStatus status) {
        return coffeeService.updateCoffeeStatusById(id, status);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteCoffeeById(@RequestParam Long id) {
        return coffeeService.deleteCoffeeById(id);
    }

}
