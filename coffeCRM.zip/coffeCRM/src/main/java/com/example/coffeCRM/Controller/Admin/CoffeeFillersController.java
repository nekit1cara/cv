package com.example.coffeCRM.Controller.Admin;

import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.example.coffeCRM.Enums.FillerType;
import com.example.coffeCRM.Service.Admin.interfaces.Coffee.CoffeeFillersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/fillers")
public class CoffeeFillersController {

    private final CoffeeFillersService coffeeFillersService;

    @Autowired
    public CoffeeFillersController(CoffeeFillersService coffeeFillersService) {
        this.coffeeFillersService = coffeeFillersService;
    }

    @GetMapping
    public ResponseEntity<Page<CoffeeFillers>> getAllFillers(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "10") int size) {
        return coffeeFillersService.getAllFillers(page, size);
    }

    @GetMapping("/type")
    public ResponseEntity<Page<CoffeeFillers>> getFillersByType(@RequestParam(defaultValue = "0") int page,
                                              @RequestParam(defaultValue = "10") int size,
                                              @RequestParam FillerType type) {
        return coffeeFillersService.getFillersByType(page, size, type);
    }

    @GetMapping("/id")
    public ResponseEntity<CoffeeFillers> getFillerById(@RequestParam Long id) {
        return coffeeFillersService.getFillerById(id);
    }

    @PostMapping("/create")
    public ResponseEntity<CoffeeFillers> createFiller(@RequestBody CoffeeFillers filler) {
        return coffeeFillersService.createFiller(filler);
    }

    @PostMapping("/create-list")
    public ResponseEntity<List<CoffeeFillers>> createFillerList(@RequestBody List<CoffeeFillers> fillers) {
        return coffeeFillersService.createFillerList(fillers);
    }

    @PutMapping("/update/{fillerId}")
    public ResponseEntity<String> updateFillerById(@PathVariable Long fillerId,
                                              @RequestBody CoffeeFillers filler) {
        return coffeeFillersService.updateFillerById(fillerId, filler);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteFillerById(@RequestParam Long fillerId) {
        return coffeeFillersService.deleteFillerById(fillerId);
    }

}
