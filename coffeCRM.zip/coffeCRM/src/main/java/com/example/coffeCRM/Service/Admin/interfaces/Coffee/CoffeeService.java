package com.example.coffeCRM.Service.Admin.interfaces.Coffee;

import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import com.example.coffeCRM.Enums.CoffeeStatus;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface CoffeeService {

    ResponseEntity<Page<Coffee>> getAllCoffee(int page, int size);

    ResponseEntity<Page<CoffeeInfo>> getCoffeeByStatus(int page, int size, CoffeeStatus status);

    ResponseEntity<CoffeeInfo> getCoffeeByName(String coffeeName);

    ResponseEntity<CoffeeInfo> getCoffeeById(Long coffeeId);

    ResponseEntity<Coffee> createCoffee(Coffee coffee);

    ResponseEntity<List<Coffee>> createCoffeeList(List<Coffee> coffees);

    ResponseEntity<String> updateCoffeeById(Long coffeeId,Coffee coffee);

    ResponseEntity<String> updateCoffeeStatusById(Long coffeeId, CoffeeStatus status);

    ResponseEntity<String> deleteCoffeeById(Long coffeeId);

}
