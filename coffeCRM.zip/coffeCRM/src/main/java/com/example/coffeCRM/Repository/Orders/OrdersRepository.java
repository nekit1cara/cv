package com.example.coffeCRM.Repository.Orders;

import com.example.coffeCRM.Entity.Orders.Orders;
import com.example.coffeCRM.Enums.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OrdersRepository extends JpaRepository<Orders,Long> {

    Optional<Orders> findBySessionIdAndOrderTrackNumber(String sessionId, String trackNumber);

    Optional<Orders> findByOrderTrackNumber(String orderTrackNumber);

    Page<Orders> findBySessionIdAndOrderStatus(String session, OrderStatus status, Pageable pageable);

    Page<Orders> findByOrderStatus(OrderStatus status, Pageable pageable);

    Page<Orders> findBySessionId(String sessionId, Pageable pageable);

    Optional<Orders> findBySessionIdAndId(String sessionId, Long id);


}
