package com.example.coffeCRM.Service.User.interfaces.Carts;

import com.example.coffeCRM.DTO.Cart.CartItemsDTO;
import com.example.coffeCRM.Entity.Carts.CartItems;
import jakarta.servlet.http.HttpSession;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

public interface UserCartsService {

    ResponseEntity<Page<CartItemsDTO>> getAllItemsInCart(HttpSession session, int page, int size);

    ResponseEntity<CartItemsDTO> getItemInCartById(HttpSession session, Long cartItemId);

    ResponseEntity<String> addItemToCart(HttpSession session, CartItems cartItems);

    ResponseEntity<String> removeItemFromCartById(HttpSession session, Long cartItemId);

    ResponseEntity<String> clearCart(HttpSession session);

}
