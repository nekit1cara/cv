package com.example.coffeCRM.Service.User.impl.Coffee;

import com.example.coffeCRM.DTO.Coffee.CoffeeFillersDTO;
import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.example.coffeCRM.Enums.FillerType;
import com.example.coffeCRM.Repository.Coffee.CoffeeFillersRepository;
import com.example.coffeCRM.Service.User.interfaces.Coffee.UserCoffeeFillersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UserCoffeeFillersServiceImpl implements UserCoffeeFillersService {

    private final CoffeeFillersRepository coffeeFillersRepository;

    @Autowired
    public UserCoffeeFillersServiceImpl(CoffeeFillersRepository coffeeFillersRepository) {
        this.coffeeFillersRepository = coffeeFillersRepository;
    }


    @Override
    public ResponseEntity<Page<CoffeeFillersDTO>> getAllFillers(int page, int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<CoffeeFillers> fillers = coffeeFillersRepository.findAll(pageable);
        Page<CoffeeFillersDTO> coffeeFillersDTO = fillers.map(CoffeeFillersDTO::fromEntity);
            return ResponseEntity.status(HttpStatus.OK).body(coffeeFillersDTO);
    }

    @Override
    public ResponseEntity<Page<CoffeeFillersDTO>> getFillersByType(int page, int size, FillerType type) {
        Pageable pageable = PageRequest.of(page,size);
        Page<CoffeeFillers> fillersByType = coffeeFillersRepository.findByFillerType(type, pageable);
        Page<CoffeeFillersDTO> fillersByTypeDTO = fillersByType.map(CoffeeFillersDTO::fromEntity);
            return ResponseEntity.status(HttpStatus.OK).body(fillersByTypeDTO);
    }

}
