package com.example.coffeCRM.Service.Admin.interfaces.Carts;

import com.example.coffeCRM.Entity.Carts.CartItems;
import jakarta.servlet.http.HttpSession;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

public interface CartsService {

    ResponseEntity<Page<CartItems>> getAllItemsInCart(HttpSession session, int page, int size);

    ResponseEntity<Optional<CartItems>> getItemInCartById(HttpSession session, Long cartItemId);

    ResponseEntity<String> addItemToCart(HttpSession session, CartItems cartItems);

    ResponseEntity<String> removeItemFromCartById(HttpSession session, Long cartItemId);

    ResponseEntity<String> clearCart(HttpSession session);

}
