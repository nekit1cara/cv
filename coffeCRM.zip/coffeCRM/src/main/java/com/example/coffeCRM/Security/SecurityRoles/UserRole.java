package com.example.coffeCRM.Security.SecurityRoles;

public enum UserRole {
    HEAD_ADMIN,
    ADMIN,
    USER
}
