package com.example.coffeCRM.Exceptions.ControllerAdvice;

import com.example.coffeCRM.Exceptions.GlobalException.CustomAlreadyExistException;
import com.example.coffeCRM.Exceptions.GlobalException.CustomConflictException;
import com.example.coffeCRM.Exceptions.GlobalException.CustomNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalControllerAdvice {

    @ExceptionHandler(CustomNotFoundException.class)
    public ResponseEntity<String> handleNotFoundException(CustomNotFoundException e) {
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CustomAlreadyExistException.class)
    public ResponseEntity<String> handleAlreadyExistException(CustomAlreadyExistException e) {
        return new ResponseEntity<>(e.getMessage(),HttpStatus.CONFLICT);
    }

    @ExceptionHandler(CustomConflictException.class)
    public ResponseEntity<String> handleCustomConflictException(CustomConflictException e) {
        return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleExceptionClass(Exception e) {
        return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
    }

}
