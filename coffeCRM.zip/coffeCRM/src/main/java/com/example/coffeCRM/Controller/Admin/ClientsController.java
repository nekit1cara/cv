package com.example.coffeCRM.Controller.Admin;

import com.example.coffeCRM.Entity.Clients.Clients;
import com.example.coffeCRM.Enums.ClientStatus;
import com.example.coffeCRM.Service.Admin.interfaces.Clients.ClientsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/clients")
public class ClientsController {

    private final ClientsService clientsService;

    @Autowired
    public ClientsController(ClientsService clientsService) {
        this.clientsService = clientsService;
    }

    @GetMapping
    public ResponseEntity<Page<Clients>> getAllClients(@RequestParam(defaultValue = "0") int page,
                                              @RequestParam(defaultValue = "10") int size) {
        return clientsService.getAllClients(page, size);
    }

    @GetMapping("/id")
    public ResponseEntity<Clients> getClientById(@RequestParam Long clientId) {
        return clientsService.getClientById(clientId);
    }

    @PostMapping("/create")
    public ResponseEntity<Clients> createClient(@RequestBody Clients client) {
        return clientsService.createClient(client);
    }

    @PostMapping("/create-list")
    public ResponseEntity<List<Clients>> createClients(@RequestBody List<Clients> clients) {
        return clientsService.createListClients(clients);
    }

    @PutMapping("/update/{clientId}")
    public ResponseEntity<String> updateClientById(@PathVariable Long clientId,
                                              @RequestBody Clients client) {
        return clientsService.updateClientById(clientId, client);
    }

    @PutMapping("/update/status")
    public ResponseEntity<String> updateClientStatusById(@RequestParam Long clientId,
                                                    @RequestParam ClientStatus status) {
        return clientsService.updateClientStatusById(clientId, status);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteClientById(@RequestParam Long clientId) {
        return clientsService.deleteClientById(clientId);
    }

}
