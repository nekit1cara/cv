package com.example.coffeCRM.DTO.Orders;

import com.example.coffeCRM.DTO.Clients.ClientsDTO;
import com.example.coffeCRM.Entity.Orders.Orders;
import com.example.coffeCRM.Enums.OrderStatus;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
public class OrdersDTO {

    @Enumerated(EnumType.STRING)
    private OrderStatus orderStatus;

    private String orderTrackNumber;

    private Integer orderTotalPrice;

    private ClientsDTO clientsDTO;

    private List<OrderItemsDTO> orderItemsDTO;

    public static OrdersDTO fromEntity(Orders orders) {

        if (orders == null) {
            return  null;
        }

        return new OrdersDTO(
                orders.getOrderStatus(),
                orders.getOrderTrackNumber(),
                orders.getOrderTotalPrice(),
                ClientsDTO.fromEntity(orders.getClients()),
                orders.getOrderItems().stream()
                        .map(OrderItemsDTO::fromEntity)
                        .collect(Collectors.toList())
        );

    }

}
