package com.example.coffeCRM.Exceptions.GlobalException;

public class CustomNotFoundException extends RuntimeException {
    public CustomNotFoundException(String message) {
        super(message);
    }
}
