package com.example.coffeCRM.Enums;

public enum CoffeeStatus {
    AVAILABLE,
    UNAVAILABLE,
    OUT_OF_STOCK,
    SEASONAL
}
