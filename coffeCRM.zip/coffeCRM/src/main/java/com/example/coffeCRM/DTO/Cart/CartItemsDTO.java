package com.example.coffeCRM.DTO.Cart;

import com.example.coffeCRM.DTO.Coffee.CoffeeDTO;
import com.example.coffeCRM.DTO.Coffee.CoffeeFillersDTO;
import com.example.coffeCRM.Entity.Carts.CartItems;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CartItemsDTO {


    private int quantity;
    private CoffeeDTO coffee;
    private CoffeeFillersDTO filler;

    public static CartItemsDTO fromEntity(CartItems cartItems) {

        if (cartItems == null) {
            return null;
        }

        return new CartItemsDTO(
                cartItems.getQuantity(),
                CoffeeDTO.fromEntity(cartItems.getCoffee()),
                CoffeeFillersDTO.fromEntity(cartItems.getFiller())
        );
    }
}
