package com.example.coffeCRM.Repository.Carts;

import com.example.coffeCRM.Entity.Carts.Carts;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CartsRepository extends JpaRepository<Carts, Long> {

    Optional<Carts> findBySessionId(String sessionId);

}
