package com.example.coffeCRM.Exceptions.GlobalException;

public class CustomAlreadyExistException extends RuntimeException {
    public CustomAlreadyExistException(String message) {
        super(message);
    }
}
