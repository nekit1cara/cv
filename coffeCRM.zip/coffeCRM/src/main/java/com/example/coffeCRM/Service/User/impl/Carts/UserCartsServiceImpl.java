package com.example.coffeCRM.Service.User.impl.Carts;

import com.example.coffeCRM.DTO.Cart.CartItemsDTO;
import com.example.coffeCRM.Entity.Carts.CartItems;
import com.example.coffeCRM.Entity.Carts.Carts;
import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.example.coffeCRM.Enums.CoffeeStatus;
import com.example.coffeCRM.Exceptions.GlobalException.CustomConflictException;
import com.example.coffeCRM.Exceptions.GlobalException.CustomNotFoundException;
import com.example.coffeCRM.Repository.Carts.CartItemsRepository;
import com.example.coffeCRM.Repository.Carts.CartsRepository;
import com.example.coffeCRM.Repository.Coffee.CoffeeFillersRepository;
import com.example.coffeCRM.Repository.Coffee.CoffeeRepository;
import com.example.coffeCRM.Service.User.interfaces.Carts.UserCartsService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class UserCartsServiceImpl implements UserCartsService {

    private final CartsRepository cartsRepository;
    private final CartItemsRepository cartItemsRepository;
    private final CoffeeRepository coffeeRepository;
    private final CoffeeFillersRepository coffeeFillersRepository;


    @Autowired
    public UserCartsServiceImpl(CartsRepository cartsRepository,
                                CartItemsRepository cartItemsRepository,
                                CoffeeRepository coffeeRepository,
                                CoffeeFillersRepository coffeeFillersRepository) {
        this.cartsRepository = cartsRepository;
        this.cartItemsRepository = cartItemsRepository;
        this.coffeeRepository = coffeeRepository;
        this.coffeeFillersRepository = coffeeFillersRepository;
    }

    @Override
    public ResponseEntity<Page<CartItemsDTO>> getAllItemsInCart(HttpSession session, int page, int size) {

        Pageable pageable = PageRequest.of(page,size);
        Page<CartItems> allItemsInCart = cartItemsRepository.findBySessionId(session.getId(), pageable);

        Page<CartItemsDTO> allItemsInCartDTO = allItemsInCart.map(CartItemsDTO::fromEntity);

            return ResponseEntity.status(HttpStatus.OK).body(allItemsInCartDTO);
    }

    @Override
    public ResponseEntity<CartItemsDTO> getItemInCartById(HttpSession session, Long cartItemId) {

        Carts cart = getOrCreateCart(session);
        CartItems cartItem = cartItemsRepository.findByIdAndSessionId(cartItemId,cart.getSessionId())
                .orElseThrow(() -> new CustomNotFoundException("Товар : " + cartItemId + " не найден в корзине."));

        CartItemsDTO cartItemDTO = CartItemsDTO.fromEntity(cartItem);

            return ResponseEntity.status(HttpStatus.OK).body(cartItemDTO);

    }

    @Override
    @Transactional
    public ResponseEntity<String> addItemToCart(HttpSession session, CartItems cartItems) {

        Carts cart = getOrCreateCart(session);
            cartItems.setSessionId(cart.getSessionId());

            if (cartItems.getQuantity() <= 0) {
                throw new CustomConflictException("Количество кофе должно быть больше 0");
            }

            // Проверка и загрузка кофе
            if (cartItems.getCoffee() == null || cartItems.getCoffee().getId() == null) {
                throw new CustomNotFoundException("Кофе не указан");
            }

        Coffee coffee = cartItems.getCoffee();
            Long coffeeId = coffee.getId();
            coffee = coffeeRepository.findById(coffeeId)
                .orElseThrow(() -> new CustomNotFoundException("Кофе с id " + cartItems.getCoffee().getId() + " не найден"));

                if (coffee.getInfo().getCoffeeStatus().equals(CoffeeStatus.UNAVAILABLE) || coffee.getInfo().getCoffeeStatus().equals(CoffeeStatus.OUT_OF_STOCK)) {
                    throw new CustomConflictException("Данный кофе : " + coffee.getInfo().getCoffeeName() + " на данный момент не досутпно.");
                }

            cartItems.setCoffee(coffee);


            // Проверка и загрузка наполнителя (опционально)
            if (cartItems.getFiller() != null && cartItems.getFiller().getId() != null) {
                CoffeeFillers filler = cartItems.getFiller();
                    Long fillerId = filler.getId();
                    filler = coffeeFillersRepository.findById(fillerId)
                        .orElseThrow(() -> new CustomNotFoundException("Наполнитель с id " + cartItems.getFiller().getId() + " не найден"));

                cartItems.setFiller(filler);
            } else {
                cartItems.setFiller(null);
            }

        cartItems.setCarts(cart);

        cart.getItems().add(cartItems);

        cartItemsRepository.save(cartItems);
            return ResponseEntity.status(HttpStatus.CREATED).body("Кофе " + coffee.getInfo().getCoffeeName() + " успешно добавлено в корзину");
    }

    @Override
    @Transactional
    public ResponseEntity<String> removeItemFromCartById(HttpSession session, Long cartItemId) {

        Optional<CartItems> itemInCart = cartItemsRepository.findByIdAndSessionId(cartItemId,session.getId());

            if (itemInCart.isEmpty()) {
                throw new CustomNotFoundException("Кофе : " + itemInCart + " не найдено в корзине");
            }


        CartItems itemToDelete = itemInCart.get();
            cartItemsRepository.delete(itemToDelete);

            return ResponseEntity.status(HttpStatus.OK).body("Кофе : " + cartItemId + " успешно удален с корзины.");
    }

    @Override
    @Transactional
    public ResponseEntity<String> clearCart(HttpSession session) {

        Carts cart = getOrCreateCart(session);
        cartItemsRepository.deleteAll(cart.getItems()); // удаляем из базы
        cart.getItems().clear(); // затем чистим в памяти, если нужно
            return ResponseEntity.status(HttpStatus.OK).body("Корзина успешно очищена");
    }


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private Carts getOrCreateCart(HttpSession session) {

        String sessionId = session.getId();
        return cartsRepository.findBySessionId(sessionId).orElseGet(() -> {
            Carts newCart = new Carts();
            newCart.setSessionId(sessionId);
            return cartsRepository.save(newCart);
        });

    }
}
