package com.example.coffeCRM.Service.User.impl.Orders;

import com.example.coffeCRM.DTO.Orders.OrdersDTO;
import com.example.coffeCRM.Entity.Carts.CartItems;
import com.example.coffeCRM.Entity.Carts.Carts;
import com.example.coffeCRM.Entity.Clients.Clients;
import com.example.coffeCRM.Entity.Orders.OrderItems;
import com.example.coffeCRM.Entity.Orders.Orders;
import com.example.coffeCRM.Enums.ClientStatus;
import com.example.coffeCRM.Enums.OrderStatus;
import com.example.coffeCRM.Exceptions.GlobalException.CustomConflictException;
import com.example.coffeCRM.Exceptions.GlobalException.CustomNotFoundException;
import com.example.coffeCRM.Repository.Carts.CartItemsRepository;
import com.example.coffeCRM.Repository.Carts.CartsRepository;
import com.example.coffeCRM.Repository.Clients.ClientsRepository;
import com.example.coffeCRM.Repository.Orders.OrderItemsRepository;
import com.example.coffeCRM.Repository.Orders.OrdersRepository;
import com.example.coffeCRM.Service.User.interfaces.Orders.UserOrdersService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class UserOrderServiceImpl implements UserOrdersService {

    private final OrdersRepository ordersRepository;
    private final OrderItemsRepository orderItemsRepository;
    private final CartsRepository cartsRepository;
    private final CartItemsRepository cartItemsRepository;
    private final ClientsRepository clientsRepository;

    @Autowired
    public UserOrderServiceImpl(OrdersRepository ordersRepository,
                                OrderItemsRepository orderItemsRepository,
                                CartsRepository cartsRepository,
                                CartItemsRepository cartItemsRepository,
                                ClientsRepository clientsRepository) {
        this.ordersRepository = ordersRepository;
        this.orderItemsRepository = orderItemsRepository;
        this.cartsRepository = cartsRepository;
        this.cartItemsRepository = cartItemsRepository;
        this.clientsRepository = clientsRepository;
    }


    @Override
    public ResponseEntity<Page<OrdersDTO>> getAllOrders(HttpSession session, int page, int size) {

        String sessionId = session.getId();
        Pageable pageable = PageRequest.of(page,size);

        Page<Orders> existingOrders = ordersRepository.findBySessionId(sessionId, pageable);

            if (existingOrders.isEmpty()) {
                throw new CustomNotFoundException("Заказы не найдены");
            }

        Page<OrdersDTO> existingOrdersDTO = existingOrders.map(OrdersDTO::fromEntity);
            return ResponseEntity.status(HttpStatus.OK).body(existingOrdersDTO);
    }

    @Override
    public ResponseEntity<OrdersDTO> getOrderByOrderTrackNumber(HttpSession session, String orderTrackNumber) {

        String sessionId = session.getId();

        Orders existingOrder = ordersRepository.findBySessionIdAndOrderTrackNumber(sessionId,orderTrackNumber)
                .orElseThrow(() -> new CustomNotFoundException("Заказ :  " + orderTrackNumber + " не найден."));

        OrdersDTO existingOrderDTO = OrdersDTO.fromEntity(existingOrder);
            return ResponseEntity.status(HttpStatus.OK).body(existingOrderDTO);
    }

    @Override
    public ResponseEntity<Page<OrdersDTO>> getOrdersByStatus(HttpSession session, int page, int size, OrderStatus status) {

        String sessionId = session.getId();
        Pageable pageable = PageRequest.of(page,size);
        Page<Orders> orderToFind = ordersRepository.findBySessionIdAndOrderStatus(sessionId,status, pageable);

            if (orderToFind.isEmpty()) {
                throw new CustomNotFoundException("Заказы со статусом : " + status + " не найдены.");
            }

        Page<OrdersDTO> ordersToFindDTO = orderToFind.map(OrdersDTO::fromEntity);
            return ResponseEntity.status(HttpStatus.OK).body(ordersToFindDTO);
    }

    @Override
    @Transactional
    public ResponseEntity<OrdersDTO> createOrder(HttpSession session, Orders order) {

        order.setSessionId(session.getId());

        order.setOrderStatus(OrderStatus.OPEN);

        order.setOrderTrackNumber("MD" + String.format("%07d",  random.nextInt(10_000_000)) + "AN");


            if (clientsRepository.existsByClientFullName(order.getClients().getClientFullName())) {

                Optional<Clients> existingClient = clientsRepository.findByClientFullName(order.getClients().getClientFullName());

                    if (existingClient.isEmpty()) {
                        throw new CustomNotFoundException("Клиент : " + order.getClients().getClientFullName() + " не найден.");
                    }

                Clients fondedClient = existingClient.get();
                    order.setClients(fondedClient);

            } else {
                Clients client = new Clients();
                    client.setClientFullName(order.getClients().getClientFullName());
                    client.setClientStatus(order.getClients().getClientStatus());
                    clientsRepository.save(client);
                order.setClients(client);
            }

            if (order.getClients() == null) {
                throw new CustomConflictException("Данные клиента не указаны.");
            }

        Carts carts = getOrCreateCart(session);

        List<CartItems> cartItems = carts.getItems();

            if (cartItems == null || cartItems.isEmpty()) {
                throw new CustomNotFoundException("Товары в корзине не найдены.");
            }

        List<OrderItems> orderItems = new ArrayList<>();
            for (CartItems cartItem : cartItems) {
                OrderItems orderItem = new OrderItems();
                    orderItem.setSessionId(order.getSessionId());
                    orderItem.setOrders(order);
                    orderItem.setCoffee(cartItem.getCoffee());
                    orderItem.setFiller(cartItem.getFiller());
                    orderItem.setQuantity(cartItem.getQuantity());
                    orderItem.setPrice(cartItem.getCoffee().getInfo().getCoffeePrice());
                orderItems.add(orderItem);
            }

        orderItemsRepository.saveAll(orderItems);
        order.setOrderItems(orderItems);
        cartItemsRepository.deleteAll(cartItems);
        order.setOrderTotalPrice(generateOrderTotalPrice(order));

            ordersRepository.save(order);

        OrdersDTO orderDTO = OrdersDTO.fromEntity(order);

        return ResponseEntity.status(HttpStatus.CREATED).body(orderDTO);
    }

    @Override
    @Transactional
    public ResponseEntity<String> deleteOrderById(HttpSession session, Long orderId) {

        Orders existingOrder = getOrder(session, orderId);
            orderItemsRepository.deleteAll(existingOrder.getOrderItems());
            existingOrder.setOrderItems(null);
            ordersRepository.delete(existingOrder);
        return ResponseEntity.status(HttpStatus.OK).body("Заказ : " + orderId + " успешно удален.");
    }


/////////////////////////////////////////////////////////            PRIVATE METHODS        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private Carts getOrCreateCart(HttpSession session) {

        String sessionId = session.getId();
        return cartsRepository.findBySessionId(sessionId).orElseGet(() -> {
            Carts newCart = new Carts();
            newCart.setSessionId(sessionId);
            return cartsRepository.save(newCart);
        });

    }

    private Orders getOrder(HttpSession session, Long orderId) {

        String sessionId = session.getId();
        return ordersRepository.findBySessionIdAndId(sessionId,orderId)
                .orElseThrow(() -> new CustomNotFoundException("Заказ : " + orderId + " не найден."));

    }


    private int generateOrderTotalPrice(Orders order) {

        int totalPrice = order.getOrderItems().stream().mapToInt(orderItem -> {
            int coffeePrice = orderItem.getPrice();
            int fillerPrice = orderItem.getFiller().getFillerPrice();
            return (coffeePrice + fillerPrice) * orderItem.getQuantity();
        }).sum();

            if (order.getClients().getClientStatus().equals(ClientStatus.VIP)) {
                totalPrice = (int) (totalPrice * 0.75); // 15% скидки
            }

        return totalPrice;
    }

    private final Random random = new Random();
}