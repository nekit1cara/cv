package com.example.coffeCRM.Service.User.interfaces.Orders;

import com.example.coffeCRM.DTO.Orders.OrdersDTO;
import com.example.coffeCRM.Entity.Orders.Orders;
import com.example.coffeCRM.Enums.OrderStatus;
import jakarta.servlet.http.HttpSession;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

public interface UserOrdersService {

    ResponseEntity<Page<OrdersDTO>> getAllOrders(HttpSession session, int page, int size);

    ResponseEntity<OrdersDTO> getOrderByOrderTrackNumber(HttpSession session, String orderTrackNumber);

    ResponseEntity<Page<OrdersDTO>> getOrdersByStatus(HttpSession session, int page, int size, OrderStatus status);

    ResponseEntity<OrdersDTO> createOrder(HttpSession session, Orders order);

    ResponseEntity<String> deleteOrderById(HttpSession session, Long orderId);

}
