package com.example.coffeCRM.Security.SecurityService.Impl;

import com.example.coffeCRM.Exceptions.GlobalException.CustomAlreadyExistException;
import com.example.coffeCRM.Exceptions.GlobalException.CustomNotFoundException;
import com.example.coffeCRM.Security.SecurityEntity.AdminPermit;
import com.example.coffeCRM.Security.SecurityRepository.AdminPermitRepository;
import com.example.coffeCRM.Security.SecurityService.Interfaces.AdminPermitService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdminPermitServiceImpl implements AdminPermitService {

    private final AdminPermitRepository adminPermitRepository;

    private final PasswordEncoder passwordEncoder;

    public AdminPermitServiceImpl(AdminPermitRepository adminPermitRepository){
        this.adminPermitRepository = adminPermitRepository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }


    @Override
    public ResponseEntity<Page<AdminPermit>> getAllAdmins(int page, int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<AdminPermit> admins = adminPermitRepository.findAll(pageable);
            return ResponseEntity.status(HttpStatus.OK).body(admins);
    }

    @Override
    public ResponseEntity<AdminPermit> getAdminByUsername(String username) {

        Optional<AdminPermit> adminToFind = adminPermitRepository.findByUsername(username);

            if (adminToFind.isEmpty()) {
                throw new CustomNotFoundException("Администратор : " + username + " не найден.");
            }

        AdminPermit foundedAdmin = adminToFind.get();
            return ResponseEntity.status(HttpStatus.OK).body(foundedAdmin);
    }

    @Override
    public ResponseEntity<AdminPermit> createAdmin(AdminPermit admin) {

        if (adminPermitRepository.existsByUsername(admin.getUsername())) {
            throw new CustomAlreadyExistException("Администратор : " + admin.getUsername() + " уже существует.");
        }

        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        adminPermitRepository.save(admin);
            return ResponseEntity.status(HttpStatus.CREATED).body(admin);
    }

    @Override
    public ResponseEntity<String> updateAdminById(Long adminId, AdminPermit newAdminValues) {

        Optional<AdminPermit> adminToFind = adminPermitRepository.findById(adminId);

        if (adminToFind.isEmpty()) {
            throw new CustomNotFoundException("Администратор : " + adminId + " не найден.");
        }

        AdminPermit adminToUpdate = adminToFind.get();

            if (newAdminValues.getUsername() != null) {
                adminToUpdate.setUsername(newAdminValues.getUsername());
            }
            if (newAdminValues.getPassword() != null) {
                adminToUpdate.setPassword(passwordEncoder.encode(newAdminValues.getPassword()));
            }
            if (newAdminValues.getUserRole() != null) {
                adminToUpdate.setUserRole(newAdminValues.getUserRole());
            }

        adminPermitRepository.save(adminToUpdate);
            return ResponseEntity.status(HttpStatus.OK).body("Администратор : " + adminId + " успешно обновлен.");
    }

    @Override
    public ResponseEntity<String> deleteAdminById(Long adminId) {

        Optional<AdminPermit> adminToFind = adminPermitRepository.findById(adminId);

            if (adminToFind.isEmpty()) {
                throw new CustomNotFoundException("Admin : " + adminId + " does not exist");
            }

        AdminPermit adminToDelete = adminToFind.get();
        adminPermitRepository.delete(adminToDelete);
            return ResponseEntity.status(HttpStatus.OK).body("Admin deleted successfully.");
    }
}
