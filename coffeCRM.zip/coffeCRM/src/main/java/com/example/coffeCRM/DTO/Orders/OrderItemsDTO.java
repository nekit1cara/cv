package com.example.coffeCRM.DTO.Orders;

import com.example.coffeCRM.DTO.Coffee.CoffeeDTO;
import com.example.coffeCRM.DTO.Coffee.CoffeeFillersDTO;
import com.example.coffeCRM.Entity.Orders.OrderItems;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OrderItemsDTO {

    private Integer quantity;

    private Integer price;

    private CoffeeDTO coffeeDTO;

    private CoffeeFillersDTO coffeeFillersDTO;

    public static OrderItemsDTO fromEntity(OrderItems orderItems) {

        if (orderItems == null) {
            return null;
        }

        return new OrderItemsDTO(
                orderItems.getQuantity(),
                orderItems.getPrice(),
                CoffeeDTO.fromEntity(orderItems.getCoffee()),
                CoffeeFillersDTO.fromEntity(orderItems.getFiller())
        );

    }

}
