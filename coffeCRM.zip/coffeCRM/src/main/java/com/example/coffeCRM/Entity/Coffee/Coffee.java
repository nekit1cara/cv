package com.example.coffeCRM.Entity.Coffee;

import com.example.coffeCRM.Entity.Carts.CartItems;
import com.example.coffeCRM.Entity.Orders.OrderItems;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Coffee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "info_id", nullable = false)
    private CoffeeInfo info;

    @JsonIgnore
    @OneToMany(mappedBy = "coffee")
    private List<CartItems> cartItems;

    @JsonIgnore
    @OneToMany(mappedBy = "coffee")
    private List<OrderItems> orderItems;

}
