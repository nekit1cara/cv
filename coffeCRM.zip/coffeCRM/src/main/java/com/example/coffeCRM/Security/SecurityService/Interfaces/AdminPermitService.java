package com.example.coffeCRM.Security.SecurityService.Interfaces;

import com.example.coffeCRM.Security.SecurityEntity.AdminPermit;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

public interface AdminPermitService {

    ResponseEntity<Page<AdminPermit>> getAllAdmins(int page, int size);

    ResponseEntity<AdminPermit> getAdminByUsername(String username);

    ResponseEntity<AdminPermit> createAdmin(AdminPermit admin);

    ResponseEntity<String> updateAdminById(Long adminId, AdminPermit newAdminValues);

    ResponseEntity<String> deleteAdminById(Long adminId);

}
