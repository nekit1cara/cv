package com.example.coffeCRM.Security.SecurityRepository;

import com.example.coffeCRM.Security.SecurityEntity.AdminPermit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AdminPermitRepository extends JpaRepository<AdminPermit,Long> {

    boolean existsByUsername(String username);

    Optional<AdminPermit> findByUsername(String username);

}
