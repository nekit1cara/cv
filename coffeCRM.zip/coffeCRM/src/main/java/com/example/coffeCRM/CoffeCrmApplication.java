package com.example.coffeCRM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeCrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoffeCrmApplication.class, args);
	}

}
