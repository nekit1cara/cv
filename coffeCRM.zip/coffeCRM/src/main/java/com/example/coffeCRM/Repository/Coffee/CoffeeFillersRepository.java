package com.example.coffeCRM.Repository.Coffee;

import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.example.coffeCRM.Enums.FillerType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoffeeFillersRepository extends JpaRepository<CoffeeFillers, Long> {

    Page<CoffeeFillers> findByFillerType(FillerType type, Pageable pageable);

    boolean existsByFillerName(String name);

}
