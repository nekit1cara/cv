package com.example.coffeCRM.Entity.Carts;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Carts {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String sessionId;

    @JsonManagedReference
    @OneToMany(mappedBy = "carts", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<CartItems> items = new ArrayList<>();

}
