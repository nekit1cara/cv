package com.example.coffeCRM.DTO.Coffee;

import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CoffeeDTO {

    private CoffeeInfoDTO coffeeInfoDTO;


    public static CoffeeDTO fromEntity(Coffee coffee) {

        if (coffee == null) {
            return null;
        }

        CoffeeInfo info = coffee.getInfo();

        return new CoffeeDTO(
                info != null ? CoffeeInfoDTO.fromEntity(info) : null
        );
    }


}
