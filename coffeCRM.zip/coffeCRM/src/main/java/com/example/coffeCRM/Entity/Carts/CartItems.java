package com.example.coffeCRM.Entity.Carts;

import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class CartItems {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String sessionId;

    private int quantity;

    @ManyToOne
    @JoinColumn(name = "coffee_id")
    private Coffee coffee;

    @ManyToOne
    @JoinColumn(name = "filler_id")
    private CoffeeFillers filler;

    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "carts_id")
    private Carts carts;
}
