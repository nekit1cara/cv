package com.example.coffeCRM.Controller.Admin;

import com.example.coffeCRM.Entity.Orders.Orders;
import com.example.coffeCRM.Enums.OrderStatus;
import com.example.coffeCRM.Service.Admin.interfaces.Orders.OrdersService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/orders")
public class OrderController {

    private final OrdersService ordersService;

    @Autowired
    public OrderController(OrdersService ordersService) {
        this.ordersService = ordersService;
    }

    @GetMapping
    public ResponseEntity<Page<Orders>> getAllOrders(HttpSession session,
                                                 @RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "10") int size) {
        return ordersService.getAllOrders(session, page, size);
    }

    @GetMapping("/track")
    public ResponseEntity<Orders> getOrderByTrackNumber(HttpSession session,
                                                   @RequestParam String trackNumber) {
        return ordersService.getOrderByOrderTrackNumber(session, trackNumber);
    }

    @GetMapping("/status")
    public ResponseEntity<Page<Orders>> getOrdersByStatus(HttpSession session,
                                               @RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "10") int size,
                                               @RequestParam OrderStatus status) {
        return ordersService.getOrdersByStatus(session, page, size, status);
    }

    @GetMapping("/id")
    public ResponseEntity<Orders> getOrderById(HttpSession session,
                                          @RequestParam Long id) {
        return ordersService.getOrderById(session, id);
    }

    @PostMapping("/create")
    public ResponseEntity<Orders> createOrder(HttpSession session,
                                         @RequestBody Orders order) {
        return ordersService.createOrder(session, order);
    }

    @PutMapping("/update/{orderId}")
    public ResponseEntity<String> updateOrderById(HttpSession session,
                                             @PathVariable Long orderId,
                                             @RequestBody Orders order) {
        return ordersService.updateOrderById(session, orderId, order);
    }

    @PutMapping("/update/status/{orderId}")
    public ResponseEntity<String> updateOrderStatusById(HttpSession session,
                                                   @PathVariable Long orderId,
                                                   @RequestParam OrderStatus status) {
        return ordersService.updateOrderStatusById(session, orderId, status);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteOrderById(HttpSession session,
                                            @RequestParam Long id) {
        return ordersService.deleteOrderById(session, id);
    }
}
