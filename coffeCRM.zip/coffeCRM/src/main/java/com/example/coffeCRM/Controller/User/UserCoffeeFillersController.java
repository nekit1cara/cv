package com.example.coffeCRM.Controller.User;

import com.example.coffeCRM.DTO.Coffee.CoffeeFillersDTO;
import com.example.coffeCRM.Enums.FillerType;
import com.example.coffeCRM.Service.User.interfaces.Coffee.UserCoffeeFillersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/fillers")
public class UserCoffeeFillersController {

    private final UserCoffeeFillersService userCoffeeFillersService;

    @Autowired
    public UserCoffeeFillersController(UserCoffeeFillersService userCoffeeFillersService) {
        this.userCoffeeFillersService = userCoffeeFillersService;
    }

    @GetMapping
    public ResponseEntity<Page<CoffeeFillersDTO>> getAllFillers(@RequestParam(defaultValue = "0") int page,
                                                                @RequestParam(defaultValue = "10") int size) {
        return userCoffeeFillersService.getAllFillers(page, size);
    }

    @GetMapping("/type")
    public ResponseEntity<Page<CoffeeFillersDTO>> getFillersByType(@RequestParam(defaultValue = "0") int page,
                                              @RequestParam(defaultValue = "10") int size,
                                              @RequestParam FillerType type) {
        return userCoffeeFillersService.getFillersByType(page, size, type);
    }

}
