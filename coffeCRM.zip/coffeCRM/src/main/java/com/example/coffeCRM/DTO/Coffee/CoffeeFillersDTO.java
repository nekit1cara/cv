package com.example.coffeCRM.DTO.Coffee;

import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.example.coffeCRM.Enums.FillerType;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CoffeeFillersDTO {

    @Enumerated(EnumType.STRING)
    private FillerType fillerType;

    private String fillerName;

    private int fillerPrice;


    public static CoffeeFillersDTO fromEntity(CoffeeFillers coffeeFillers) {

        if (coffeeFillers == null) {
            return null;
        }

        return new CoffeeFillersDTO(
                coffeeFillers.getFillerType(),
                coffeeFillers.getFillerName(),
                coffeeFillers.getFillerPrice()
        );

    }

}
