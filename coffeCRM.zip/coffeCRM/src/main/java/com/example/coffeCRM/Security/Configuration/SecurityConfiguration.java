package com.example.coffeCRM.Security.Configuration;


import com.example.coffeCRM.Security.SecurityService.Impl.MyUserDetailsServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractAuthenticationFilterConfigurer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfiguration {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        return http.csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/fillers",
                                        "api/fillers/type",
                                        "api/coffee",
                                        "api/coffee/status",
                                        "api/coffee/name",
                                        "api/cart",
                                        "api/cart/item",
                                        "api/cart/add-item",
                                        "api/cart/clear",
                                        "api/cart/remove",
                                        "api/orders",
                                        "api/orders/track",
                                        "api/orders/status",
                                        "api/orders/create",
                                        "api/orders/delete",
                                        "/error",
                                        "/login")
                        .permitAll()
                    .anyRequest().fullyAuthenticated())
                .formLogin(AbstractAuthenticationFilterConfigurer::permitAll)
                .build();

    }


    @Bean
    public UserDetailsService userDetailsService() {
        return new MyUserDetailsServiceImpl();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
            authProvider.setUserDetailsService(userDetailsService());
            authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

}
