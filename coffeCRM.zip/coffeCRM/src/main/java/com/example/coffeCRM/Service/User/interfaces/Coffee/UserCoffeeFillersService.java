package com.example.coffeCRM.Service.User.interfaces.Coffee;

import com.example.coffeCRM.DTO.Coffee.CoffeeFillersDTO;
import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.example.coffeCRM.Enums.FillerType;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;


public interface UserCoffeeFillersService {

    ResponseEntity<Page<CoffeeFillersDTO>> getAllFillers(int page, int size);

    ResponseEntity<Page<CoffeeFillersDTO>> getFillersByType(int page, int size, FillerType type);

}
