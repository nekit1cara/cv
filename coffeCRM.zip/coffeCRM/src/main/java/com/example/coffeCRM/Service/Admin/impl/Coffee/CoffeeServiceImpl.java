package com.example.coffeCRM.Service.Admin.impl.Coffee;

import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import com.example.coffeCRM.Enums.CoffeeStatus;
import com.example.coffeCRM.Exceptions.GlobalException.CustomAlreadyExistException;
import com.example.coffeCRM.Exceptions.GlobalException.CustomNotFoundException;
import com.example.coffeCRM.Repository.Coffee.CoffeeInfoRepository;
import com.example.coffeCRM.Repository.Coffee.CoffeeRepository;
import com.example.coffeCRM.Service.Admin.interfaces.Coffee.CoffeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
import java.util.Optional;

@Service
public class CoffeeServiceImpl implements CoffeeService {

    private final CoffeeRepository coffeeRepository;

    private final CoffeeInfoRepository coffeeInfoRepository;

    @Autowired
    public CoffeeServiceImpl(CoffeeRepository coffeeRepository, CoffeeInfoRepository coffeeInfoRepository) {
        this.coffeeRepository = coffeeRepository;
        this.coffeeInfoRepository = coffeeInfoRepository;
    }


    @Override
    public ResponseEntity<Page<Coffee>> getAllCoffee(int page, int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<Coffee> coffees = coffeeRepository.findAll(pageable);
            return ResponseEntity.status(HttpStatus.OK).body(coffees);

    }

    @Override
    public ResponseEntity<Page<CoffeeInfo>> getCoffeeByStatus(int page, int size, CoffeeStatus status) {

        Pageable pageable = PageRequest.of(page,size);
        Page<CoffeeInfo> coffeeByStatus = coffeeInfoRepository.findByCoffeeStatus(status,pageable);
            return ResponseEntity.status(HttpStatus.OK).body(coffeeByStatus);

    }

    @Override
    public ResponseEntity<CoffeeInfo> getCoffeeByName(String coffeeName) {

        Optional<CoffeeInfo> existingCoffee = coffeeInfoRepository.findByCoffeeName(coffeeName);

            if (existingCoffee.isEmpty()) {
                throw new CustomNotFoundException("Модель кофе : " + coffeeName + " не найден.");
            }

        CoffeeInfo foundedCoffee = existingCoffee.get();
            return ResponseEntity.status(HttpStatus.OK).body(foundedCoffee);
    }

    @Override
    public ResponseEntity<CoffeeInfo> getCoffeeById(Long coffeeId) {

        Optional<CoffeeInfo> existingCoffee = coffeeInfoRepository.findById(coffeeId);

            if (existingCoffee.isEmpty()) {
                throw new CustomNotFoundException("Модель кофе : " + coffeeId + " не найден.");
            }

        CoffeeInfo foundedCoffee = existingCoffee.get();
            return ResponseEntity.status(HttpStatus.OK).body(foundedCoffee);
    }

    @Override
    @Transactional
    public ResponseEntity<Coffee> createCoffee(Coffee coffee) {

            if (coffeeInfoRepository.existsByCoffeeName(coffee.getInfo().getCoffeeName())) {
                throw new CustomAlreadyExistException("Данное кофе : " + coffee.getInfo().getCoffeeName() + " уже существует.");
            }

        CoffeeInfo coffeeInfo = createNewCoffeeInfo(coffee);
        coffeeInfoRepository.save(coffeeInfo);
        coffee.setInfo(coffeeInfo);
        coffeeRepository.save(coffee);
            return ResponseEntity.status(HttpStatus.CREATED).body(coffee);

    }



    @Override
    @Transactional
    public ResponseEntity<List<Coffee>> createCoffeeList(List<Coffee> coffees) {

        for (Coffee coffee : coffees) {
                if (coffeeInfoRepository.existsByCoffeeName(coffee.getInfo().getCoffeeName())) {
                    throw new CustomAlreadyExistException("Данное кофе : " + coffee.getInfo().getCoffeeName() + " уже существует.");
                }

            CoffeeInfo coffeeInfo = createNewCoffeeInfo(coffee);
            coffeeInfoRepository.save(coffeeInfo);
            coffee.setInfo(coffeeInfo);
            coffeeRepository.save(coffee);
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(coffees);
    }

    @Override
    @Transactional
    public ResponseEntity<String> updateCoffeeById(Long coffeeId, Coffee coffee) {

        Optional<Coffee> coffeeToFound = coffeeRepository.findById(coffeeId);

            if (coffeeToFound.isEmpty()) {
                throw new CustomAlreadyExistException("Кофе : " + coffeeId + " не найден.");
            }

        Coffee existingCoffee = coffeeToFound.get();
        CoffeeInfo existingCoffeeInfo = existingCoffee.getInfo();

            if (coffee.getInfo().getCoffeeName() != null) {
                existingCoffeeInfo.setCoffeeName(coffee.getInfo().getCoffeeName());
            }
            if (coffee.getInfo().getCoffeeStatus() != null) {
                existingCoffeeInfo.setCoffeeStatus(coffee.getInfo().getCoffeeStatus());
            }
            if (coffee.getInfo().getCoffeeWeight() != 0) {
                existingCoffeeInfo.setCoffeeWeight(coffee.getInfo().getCoffeeWeight());
            }
            if (coffee.getInfo().getCoffeeDescription() != null) {
                existingCoffeeInfo.setCoffeeDescription(coffee.getInfo().getCoffeeDescription());
            }
            if (coffee.getInfo().getCoffeePrice() != 0) {
                existingCoffeeInfo.setCoffeePrice(coffee.getInfo().getCoffeePrice());
            }

        coffeeInfoRepository.save(existingCoffeeInfo);
        coffeeRepository.save(existingCoffee);
            return ResponseEntity.status(HttpStatus.OK).body("Кофе : " + coffeeId + " успешно обновленно.");
    }

    @Override
    @Transactional
    public ResponseEntity<String> updateCoffeeStatusById(Long coffeeId, CoffeeStatus status) {

        Optional<Coffee> coffeeToFound = coffeeRepository.findById(coffeeId);

        if (coffeeToFound.isEmpty()) {
            throw new CustomAlreadyExistException("Кофе : " + coffeeId + " не найден.");
        }

        Coffee existingCoffee = coffeeToFound.get();
        CoffeeInfo existingCoffeeInfo = existingCoffee.getInfo();
            existingCoffeeInfo.setCoffeeStatus(status);

        coffeeInfoRepository.save(existingCoffeeInfo);
        coffeeRepository.save(existingCoffee);
            return ResponseEntity.status(HttpStatus.OK).body("Статус у кофе : " + coffeeId + " успешно обновлен.");
    }

    @Override
    @Transactional
    public ResponseEntity<String> deleteCoffeeById(Long coffeeId) {

        Optional<Coffee> coffeeToFound = coffeeRepository.findById(coffeeId);

            if (coffeeToFound.isEmpty()) {
                throw new CustomAlreadyExistException("Кофе : " + coffeeId + " не найден.");
            }

        Coffee existingCoffee = coffeeToFound.get();
        CoffeeInfo existingCoffeeInfo = existingCoffee.getInfo();
            coffeeInfoRepository.delete(existingCoffeeInfo);
            existingCoffee.setInfo(null);
            coffeeRepository.delete(existingCoffee);

            return ResponseEntity.status(HttpStatus.OK).body("Кофе : " + coffeeId + " успешно удалено.");

    }


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private static CoffeeInfo createNewCoffeeInfo(Coffee coffee) {
        CoffeeInfo coffeeInfo = new CoffeeInfo();
        coffeeInfo.setCoffeeStatus(CoffeeStatus.AVAILABLE);
        coffeeInfo.setCoffeeName(coffee.getInfo().getCoffeeName());
        coffeeInfo.setCoffeeWeight(coffee.getInfo().getCoffeeWeight());
        coffeeInfo.setCoffeeDescription(coffee.getInfo().getCoffeeDescription());
        coffeeInfo.setCoffeePrice(coffee.getInfo().getCoffeePrice());
        return coffeeInfo;
    }

}
