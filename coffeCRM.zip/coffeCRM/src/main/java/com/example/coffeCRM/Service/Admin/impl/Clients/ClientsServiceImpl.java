package com.example.coffeCRM.Service.Admin.impl.Clients;

import com.example.coffeCRM.Entity.Clients.Clients;
import com.example.coffeCRM.Enums.ClientStatus;
import com.example.coffeCRM.Exceptions.GlobalException.CustomAlreadyExistException;
import com.example.coffeCRM.Exceptions.GlobalException.CustomNotFoundException;
import com.example.coffeCRM.Repository.Clients.ClientsRepository;
import com.example.coffeCRM.Service.Admin.interfaces.Clients.ClientsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClientsServiceImpl implements ClientsService {

    private final ClientsRepository clientsRepository;

    @Autowired
    public ClientsServiceImpl(ClientsRepository clientsRepository) {
        this.clientsRepository = clientsRepository;
    }


    @Override
    public ResponseEntity<Page<Clients>> getAllClients(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Clients> clients = clientsRepository.findAll(pageable);
            return ResponseEntity.status(HttpStatus.OK).body(clients);
    }

    @Override
    public ResponseEntity<Clients> getClientById(Long clientId) {

        Optional<Clients> clientToFind = clientsRepository.findById(clientId);

            if (clientToFind.isEmpty()) {
                throw new CustomNotFoundException("Клиент : " + clientId + " не найден.");
            }

        Clients existingClient = clientToFind.get();
            return ResponseEntity.status(HttpStatus.OK).body(existingClient);

    }

    @Override
    public ResponseEntity<Clients> createClient(Clients client) {

        if (clientsRepository.existsByClientFullName(client.getClientFullName())) {
            throw new CustomAlreadyExistException("Клиент : " + client.getId() + " уже существует.");
        }

        client.setClientStatus(ClientStatus.CLASSIC);
        clientsRepository.save(client);
            return ResponseEntity.status(HttpStatus.CREATED).body(client);
    }

    @Override
    public ResponseEntity<List<Clients>> createListClients(List<Clients> clients) {

        for (Clients client : clients) {
            if (clientsRepository.existsByClientFullName(client.getClientFullName())) {
                throw new CustomAlreadyExistException("Клиент : " + client.getId() + " уже существует.");
            }

            client.setClientStatus(ClientStatus.CLASSIC);
            clientsRepository.save(client);
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(clients);
    }

    @Override
    public ResponseEntity<String> updateClientById(Long clientId, Clients client) {

        Optional<Clients> clientToFind = clientsRepository.findById(clientId);

            if (clientToFind.isEmpty()) {
                throw new CustomNotFoundException("Клиент : " + clientId + " не найден.");
            }

        Clients existingClient = clientToFind.get();

            if (client.getClientFullName() != null) {
                existingClient.setClientFullName(client.getClientFullName());
            }
            if (client.getClientStatus() != null) {
                existingClient.setClientStatus(client.getClientStatus());
            }

        clientsRepository.save(existingClient);
            return ResponseEntity.status(HttpStatus.OK).body("Клиент : " + clientId + " успешно обновлен.");
    }

    @Override
    public ResponseEntity<String> updateClientStatusById(Long clientId, ClientStatus status) {

        Optional<Clients> clientToFind = clientsRepository.findById(clientId);

            if (clientToFind.isEmpty()) {
                throw new CustomNotFoundException("Клиент : " + clientId + " не найден.");
            }

        Clients existingClient = clientToFind.get();
            existingClient.setClientStatus(status);
        clientsRepository.save(existingClient);
            return ResponseEntity.status(HttpStatus.OK).body("Статус клиента : " + clientId + " успешно обновлен на : " + status);
    }

    @Override
    public ResponseEntity<String> deleteClientById(Long clientId) {

        Optional<Clients> clientToFind = clientsRepository.findById(clientId);

            if (clientToFind.isEmpty()) {
                throw new CustomNotFoundException("Клиент : " + clientId + " не найден.");
            }

        Clients existingClient = clientToFind.get();
            clientsRepository.delete(existingClient);
            return ResponseEntity.status(HttpStatus.OK).body("Клиент : " + clientId + " успешно удален.");

    }
}