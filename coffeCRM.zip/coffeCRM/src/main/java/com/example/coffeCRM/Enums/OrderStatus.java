package com.example.coffeCRM.Enums;

public enum OrderStatus {

    OPEN,
    PENDING,
    PAID,
    CLOSE,
    CANCELED

}
