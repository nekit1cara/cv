package com.example.coffeCRM.Service.User.impl.Coffee;

import com.example.coffeCRM.DTO.Coffee.CoffeeDTO;
import com.example.coffeCRM.DTO.Coffee.CoffeeInfoDTO;
import com.example.coffeCRM.Entity.Coffee.Coffee;
import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import com.example.coffeCRM.Enums.CoffeeStatus;
import com.example.coffeCRM.Exceptions.GlobalException.CustomNotFoundException;
import com.example.coffeCRM.Repository.Coffee.CoffeeInfoRepository;
import com.example.coffeCRM.Repository.Coffee.CoffeeRepository;
import com.example.coffeCRM.Service.User.interfaces.Coffee.UserCoffeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UserCoffeeServiceImpl implements UserCoffeeService {

    private final CoffeeRepository coffeeRepository;

    private final CoffeeInfoRepository coffeeInfoRepository;

    @Autowired
    public UserCoffeeServiceImpl(CoffeeRepository coffeeRepository, CoffeeInfoRepository coffeeInfoRepository) {
        this.coffeeRepository = coffeeRepository;
        this.coffeeInfoRepository = coffeeInfoRepository;
    }


    @Override
    public ResponseEntity<Page<CoffeeDTO>> getAllCoffee(int page, int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<Coffee> coffees = coffeeRepository.findAll(pageable);

        Page<CoffeeDTO> coffeeDTO = coffees.map(CoffeeDTO::fromEntity);

            return ResponseEntity.status(HttpStatus.OK).body(coffeeDTO);

    }

    @Override
    public ResponseEntity<Page<CoffeeInfoDTO>> getCoffeeByStatus(int page, int size, CoffeeStatus status) {

        Pageable pageable = PageRequest.of(page,size);
        Page<CoffeeInfo> coffeeByStatus = coffeeInfoRepository.findByCoffeeStatus(status,pageable);

        Page<CoffeeInfoDTO> coffeeInfoDTO = coffeeByStatus.map(CoffeeInfoDTO::fromEntity);
            return ResponseEntity.status(HttpStatus.OK).body(coffeeInfoDTO);

    }

    @Override
    public ResponseEntity<CoffeeInfoDTO> getCoffeeByName(String coffeeName) {

        Optional<CoffeeInfo> existingCoffee = coffeeInfoRepository.findByCoffeeName(coffeeName);

            if (existingCoffee.isEmpty()) {
                throw new CustomNotFoundException("Модель кофе : " + coffeeName + " не найден.");
            }

        CoffeeInfo foundedCoffee = existingCoffee.get();

        CoffeeInfoDTO coffeeInfoDTO = CoffeeInfoDTO.fromEntity(foundedCoffee);
            return ResponseEntity.status(HttpStatus.OK).body(coffeeInfoDTO);
    }

}
