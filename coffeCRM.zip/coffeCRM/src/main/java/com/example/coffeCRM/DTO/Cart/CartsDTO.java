package com.example.coffeCRM.DTO.Cart;

import com.example.coffeCRM.Entity.Carts.Carts;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
public class CartsDTO {

    private List<CartItemsDTO> items;

    public static CartsDTO fromEntity(Carts carts) {

        if (carts == null) {
            return null;
        }

        return new CartsDTO(
                carts.getItems().stream()
                        .map(CartItemsDTO::fromEntity)
                        .collect(Collectors.toList())
        );
    }
}

