package com.example.coffeCRM.Controller.Admin;

import com.example.coffeCRM.Entity.Carts.CartItems;
import com.example.coffeCRM.Service.Admin.interfaces.Carts.CartsService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/admin/cart")
public class CartsController {

    private final CartsService cartsService;

    @Autowired
    public CartsController(CartsService cartsService) {
        this.cartsService = cartsService;
    }

    @GetMapping
    public ResponseEntity<Page<CartItems>> getAllItemsInCart(HttpSession session,
                                                  @RequestParam(defaultValue = "0") int page,
                                                  @RequestParam(defaultValue = "10") int size) {
        return cartsService.getAllItemsInCart(session, page, size);
    }

    @GetMapping("/item")
    public ResponseEntity<Optional<CartItems>> getCartItemById(HttpSession session,
                                                    @RequestParam Long id) {
        return cartsService.getItemInCartById(session, id);
    }

    @PostMapping("/add-item")
    public ResponseEntity<String> addItemInCart(HttpSession session,
                                           @RequestBody CartItems item) {
        return cartsService.addItemToCart(session, item);
    }

    @DeleteMapping("/remove")
    public ResponseEntity<String> removeItemFromCart(HttpSession session,
                                                @RequestParam Long itemId) {
        return cartsService.removeItemFromCartById(session, itemId);
    }

    @DeleteMapping("/clear")
    public ResponseEntity<String> clearCart(HttpSession session) {
        return cartsService.clearCart(session);
    }

}
