package com.example.coffeCRM.Repository.Orders;

import com.example.coffeCRM.Entity.Orders.OrderItems;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemsRepository extends JpaRepository<OrderItems,Long> {
}
