package com.example.coffeCRM.Entity.Orders;

import com.example.coffeCRM.Entity.Clients.Clients;
import com.example.coffeCRM.Enums.OrderStatus;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String sessionId;

    @Enumerated(EnumType.STRING)
    private OrderStatus orderStatus;

    private String orderTrackNumber;

    private Integer orderTotalPrice;

    @ManyToOne
    @JoinColumn(name = "clients_id")
    private Clients clients;


    @JsonManagedReference
    @OneToMany(mappedBy = "orders", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<OrderItems> orderItems = new ArrayList<>();
}
