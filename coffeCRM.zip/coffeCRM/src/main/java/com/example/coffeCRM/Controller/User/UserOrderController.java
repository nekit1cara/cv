package com.example.coffeCRM.Controller.User;

import com.example.coffeCRM.DTO.Orders.OrdersDTO;
import com.example.coffeCRM.Entity.Orders.Orders;
import com.example.coffeCRM.Enums.OrderStatus;
import com.example.coffeCRM.Service.User.interfaces.Orders.UserOrdersService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class UserOrderController {

    private final UserOrdersService userOrdersService;

    @Autowired
    public UserOrderController(UserOrdersService userOrdersService) {
        this.userOrdersService = userOrdersService;
    }

    @GetMapping
    public ResponseEntity<Page<OrdersDTO>> getAllOrders(HttpSession session,
                                                        @RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "10") int size) {
        return userOrdersService.getAllOrders(session, page, size);
    }

    @GetMapping("/track")
    public ResponseEntity<OrdersDTO> getOrderByTrackNumber(HttpSession session,
                                                   @RequestParam String trackNumber) {
        return userOrdersService.getOrderByOrderTrackNumber(session, trackNumber);
    }

    @GetMapping("/status")
    public ResponseEntity<Page<OrdersDTO>> getOrdersByStatus(HttpSession session,
                                               @RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "10") int size,
                                               @RequestParam OrderStatus status) {
        return userOrdersService.getOrdersByStatus(session, page, size, status);
    }

    @PostMapping("/create")
    public ResponseEntity<OrdersDTO> createOrder(HttpSession session,
                                         @RequestBody Orders order) {
        return userOrdersService.createOrder(session, order);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteOrderById(HttpSession session,
                                            @RequestParam Long id) {
        return userOrdersService.deleteOrderById(session, id);
    }
}
