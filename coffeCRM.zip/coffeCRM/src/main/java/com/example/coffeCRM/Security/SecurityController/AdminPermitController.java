package com.example.coffeCRM.Security.SecurityController;

import com.example.coffeCRM.Security.SecurityEntity.AdminPermit;
import com.example.coffeCRM.Security.SecurityService.Interfaces.AdminPermitService;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
public class AdminPermitController {

    private final AdminPermitService adminPermitService;

    public AdminPermitController(AdminPermitService adminPermitService) {
        this.adminPermitService = adminPermitService;
    }

    @GetMapping
    public ResponseEntity<Page<AdminPermit>> getAllAdmins(@RequestParam(defaultValue = "0") int page,
                                                          @RequestParam(defaultValue = "10") int size) {
        return adminPermitService.getAllAdmins(page, size);
    }

    @GetMapping("/username")
    public ResponseEntity<AdminPermit> getAdminByUsername(@RequestParam String username) {
        return  adminPermitService.getAdminByUsername(username);
    }

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('HEAD_ADMIN')")
    public ResponseEntity<AdminPermit> createAdmin(@RequestBody AdminPermit admin) {
        return adminPermitService.createAdmin(admin);
    }

    @PutMapping("/update/{adminId}")
    @PreAuthorize("hasAuthority('HEAD_ADMIN')")
    public ResponseEntity<String> updateAdminById(@PathVariable Long adminId, @RequestBody AdminPermit newAdminValues) {
        return adminPermitService.updateAdminById(adminId, newAdminValues);
    }

    @DeleteMapping("/delete/{adminId}")
    @PreAuthorize("hasAuthority('HEAD_ADMIN')")
    public ResponseEntity<String> deleteAdminById(@PathVariable Long adminId) {
        return  adminPermitService.deleteAdminById(adminId);
    }

}
