package com.example.coffeCRM.Repository.Coffee;

import com.example.coffeCRM.Entity.Coffee.CoffeeInfo;
import com.example.coffeCRM.Enums.CoffeeStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CoffeeInfoRepository extends JpaRepository<CoffeeInfo,Long> {

    Page<CoffeeInfo> findByCoffeeStatus(CoffeeStatus status, Pageable pageable);

    Optional<CoffeeInfo> findByCoffeeName(String name);

    boolean existsByCoffeeName(String name);

}
