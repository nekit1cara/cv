package com.example.coffeCRM.DTO.Clients;

import com.example.coffeCRM.Entity.Clients.Clients;
import com.example.coffeCRM.Enums.ClientStatus;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ClientsDTO {

    @Enumerated(EnumType.STRING)
    private ClientStatus clientStatus;

    private String clientFullName;


    public static ClientsDTO fromEntity(Clients clients) {

        if (clients == null) {
            return null;
        }

        return new ClientsDTO(
                clients.getClientStatus(),
                clients.getClientFullName()
        );

    }


}
