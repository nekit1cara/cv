package com.example.coffeCRM.Service.Admin.interfaces.Orders;

import com.example.coffeCRM.Entity.Orders.Orders;
import com.example.coffeCRM.Enums.OrderStatus;
import jakarta.servlet.http.HttpSession;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

public interface OrdersService {

    ResponseEntity<Page<Orders>> getAllOrders(HttpSession session, int page, int size);

    ResponseEntity<Orders> getOrderByOrderTrackNumber(HttpSession session, String orderTrackNumber);


    ResponseEntity<Page<Orders>> getOrdersByStatus(HttpSession session, int page, int size, OrderStatus status);

    ResponseEntity<Orders> getOrderById(HttpSession session, Long orderId);

    ResponseEntity<Orders> createOrder(HttpSession session, Orders order);

    ResponseEntity<String> updateOrderById(HttpSession session, Long orderId, Orders order);

    ResponseEntity<String> updateOrderStatusById(HttpSession session, Long orderId, OrderStatus status);

    ResponseEntity<String> deleteOrderById(HttpSession session, Long orderId);

}
