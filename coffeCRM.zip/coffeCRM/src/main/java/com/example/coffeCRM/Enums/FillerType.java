package com.example.coffeCRM.Enums;

public enum FillerType {
    SYRUP
}
