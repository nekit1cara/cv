package com.example.coffeCRM.Service.Admin.impl.Coffee;

import com.example.coffeCRM.Entity.Coffee.CoffeeFillers;
import com.example.coffeCRM.Enums.FillerType;
import com.example.coffeCRM.Exceptions.GlobalException.CustomAlreadyExistException;
import com.example.coffeCRM.Exceptions.GlobalException.CustomNotFoundException;
import com.example.coffeCRM.Repository.Coffee.CoffeeFillersRepository;
import com.example.coffeCRM.Service.Admin.interfaces.Coffee.CoffeeFillersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CoffeeFillersServiceImpl implements CoffeeFillersService {

    private final CoffeeFillersRepository coffeeFillersRepository;

    @Autowired
    public CoffeeFillersServiceImpl(CoffeeFillersRepository coffeeFillersRepository) {
        this.coffeeFillersRepository = coffeeFillersRepository;
    }


    @Override
    public ResponseEntity<Page<CoffeeFillers>> getAllFillers(int page, int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<CoffeeFillers> fillers = coffeeFillersRepository.findAll(pageable);
            return ResponseEntity.status(HttpStatus.OK).body(fillers);
    }

    @Override
    public ResponseEntity<Page<CoffeeFillers>> getFillersByType(int page, int size, FillerType type) {
        Pageable pageable = PageRequest.of(page,size);
        Page<CoffeeFillers> fillersByType = coffeeFillersRepository.findByFillerType(type, pageable);
            return ResponseEntity.status(HttpStatus.OK).body(fillersByType);
    }

    @Override
    public ResponseEntity<CoffeeFillers> getFillerById(Long fillerId) {

        Optional<CoffeeFillers> existingFiller = coffeeFillersRepository.findById(fillerId);

            if (existingFiller.isEmpty()) {
                throw new CustomNotFoundException("Наполнитель : " + fillerId + " не найден.");
            }

        CoffeeFillers foundedFiller = existingFiller.get();
            return ResponseEntity.status(HttpStatus.OK).body(foundedFiller);

    }

    @Override
    public ResponseEntity<CoffeeFillers> createFiller(CoffeeFillers filler) {

            if (coffeeFillersRepository.existsByFillerName(filler.getFillerName())) {
                throw new CustomAlreadyExistException("Наполнитель : " + filler.getFillerName() + " уже существует.");
            }

        coffeeFillersRepository.save(filler);
            return ResponseEntity.status(HttpStatus.CREATED).body(filler);
    }

    @Override
    public ResponseEntity<List<CoffeeFillers>> createFillerList(List<CoffeeFillers> fillers) {

        for (CoffeeFillers filler : fillers) {

            if (coffeeFillersRepository.existsByFillerName(filler.getFillerName())) {
                throw new CustomAlreadyExistException("Наполнитель : " + filler.getFillerName() + " уже существует.");
            }

            coffeeFillersRepository.save(filler);
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(fillers);
    }

    @Override
    public ResponseEntity<String> updateFillerById(Long fillerId, CoffeeFillers filler) {

       Optional<CoffeeFillers> existingFiller = coffeeFillersRepository.findById(fillerId);

            if (existingFiller.isEmpty()) {
                throw new CustomNotFoundException("Наполнитель : " + fillerId + " не найден.");
            }

       CoffeeFillers foundedFiller = existingFiller.get();

            if (filler.getFillerName() != null) {
                foundedFiller.setFillerName(filler.getFillerName());
            }
            if (filler.getFillerPrice() != 0) {
                foundedFiller.setFillerPrice(filler.getFillerPrice());
            }
            if (filler.getFillerType() != null) {
                foundedFiller.setFillerType(filler.getFillerType());
            }

       coffeeFillersRepository.save(foundedFiller);
            return ResponseEntity.status(HttpStatus.OK).body("Наполнитель : " + fillerId + " успешно обновлен.");
    }

    @Override
    public ResponseEntity<String> deleteFillerById(Long fillerId) {

        Optional<CoffeeFillers> existingFiller = coffeeFillersRepository.findById(fillerId);

            if (existingFiller.isEmpty()) {
                throw new CustomNotFoundException("Наполнитель : " + fillerId + " не найден.");
            }

        CoffeeFillers foundedFiller = existingFiller.get();
        coffeeFillersRepository.delete(foundedFiller);
            return ResponseEntity.status(HttpStatus.OK).body("Наполнитель : " + fillerId + " успешно удален.");
    }
}
