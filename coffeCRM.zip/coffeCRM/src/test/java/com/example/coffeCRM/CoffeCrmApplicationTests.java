package com.example.coffeCRM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeCrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
